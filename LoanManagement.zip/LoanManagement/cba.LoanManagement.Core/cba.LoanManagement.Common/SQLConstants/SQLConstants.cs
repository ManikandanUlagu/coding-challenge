﻿using System;

namespace cba.LoanManagement.Common
{
    public static class SqlConstants
    {
        public const string LoanList = @"SELECT * AAA
                                           FROM WHERE AcNumber=@acNumber ";
    }
}
