using System;
using Xunit;

namespace cba.LoanManagement.UnitTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
