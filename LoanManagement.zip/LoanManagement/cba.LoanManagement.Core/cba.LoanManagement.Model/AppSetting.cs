﻿using System;

namespace cba.LoanManagement.Model
{
    public class AppSetting
    {
        public string DatabaseConnectionString { get; set; }
    }
}
